﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace library
{
    static class PublicVar
    {
        public static int access = 0;
        public static int user_id = 0;
        public static string name_user = "";
    }
}
